


import java.util.ArrayList;
import java.util.Random;

public class Rook implements RookInterface {
    private Pair position;
    private Random random = new Random();

    public Rook(Pair position) {
        this.position = position;
    }

    // move code = 0
    /**
     * changes the position of the piece
     * @return String that represents a move "e2e4"
     */
    @Override
    public String moveForward() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while ((((position.y - i *direction) * 9 + position.x + 1) >= 0) &&
                (((position.y - i *direction) * 9 + position.x + 1) < 73)) {
            // if we find a blank square we could go further
            // if we find a enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt((position.y - i *direction) * 9 + position.x + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt((position.y - i *direction) * 9 + position.x + 1)) >= 0){
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char)(position.x + 'a') +
                String.valueOf((position.y + 1 - numberOfRows * direction));
        position.y -= numberOfRows * direction;
        position.x += 0;

        return move;
    }

    // move code = 1
    /**
     * changes the position of the piece
     * @return String that represents a move "e2e4"
     */
    @Override
    public String moveLeft() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while (((position.y * 9 + (position.x  - i *direction) + 1) >= 0) &&
                ((position.y * 9 + (position.x  - i *direction) + 1) < 73)){
            // if we find a blank square we could go further
            // if we find a enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt(position.y * 9 + (position.x  - i *direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt(position.y * 9 + (position.x  - i *direction) + 1)) >= 0){
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char)(position.x + 'a' - numberOfRows * direction) +
                String.valueOf((position.y + 1));
        position.y += 0;
        position.x -= numberOfRows * direction;

        return move;
    }

    // move code = 2
    /**
     * changes the position of the piece
     * @return String that represents a move "e2e4"
     */
    @Override
    public String moveRight() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while (((position.y * 9 + (position.x  + i *direction) + 1) >= 0) &&
                ((position.y * 9 + (position.x  + i *direction) + 1) < 73)){
            // if we find a blank square we could go further
            // if we find a enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt(position.y * 9 + (position.x  + i *direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt(position.y * 9 + (position.x  + i *direction) + 1)) >= 0){
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char)(position.x + 'a' + numberOfRows * direction) +
                String.valueOf((position.y + 1));
        position.y += 0;
        position.x += numberOfRows * direction;

        return move;
    }

    // move code = 3
    /**
     * changes the position of the piece
     * @return String that represents a move "e2e4"
     */
    @Override
    public String moveBack() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while ((((position.y + i *direction) * 9 + position.x + 1) >= 0) &&
                (((position.y + i *direction) * 9 + position.x + 1) < 73)){
            // if we find a blank square we could go further
            // if we find a enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt((position.y + i *direction) * 9 + position.x + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt((position.y + i *direction) * 9 + position.x + 1)) >= 0){
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char)(position.x + 'a') +
                String.valueOf((position.y + 1 + numberOfRows * direction));
        position.y += numberOfRows * direction;
        position.x += 0;

        return move;
    }

    /**
     *
     * @param chessBoard the current state of the board
     * @return String that represents a valid move
     * returns null if no moves can be made by this piece
     */
    @Override
    public String makeValidMove(String chessBoard) {
        String move = null;
        ArrayList<Integer> possibleMoves = new ArrayList<>();

        System.out.println(position.x + " " + position.y);

        // change depending on with what pieces the AI plays
        Integer direction = Moves.getInstance().getDirectionController();
        String enemyArray = Moves.getInstance().getEnemyArray() + "*";

        // check validity for the forward move
        // code 0
        if ((((position.y - (1 * direction)) * 9 + (position.x) + 1) >= 0) &&
                (((position.y - (1 * direction)) * 9 + (position.x ) + 1) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt((
                        position.y - (1 * direction)) * 9 + (position.x) + 1)) >= 0)) {
            possibleMoves.add(0);
        }
        // check validity for the move left
        // code 1
        if ((((position.y) * 9 + (position.x  - (1 * direction) + 1)) >= 0) &&
                (((position.y) * 9 + (position.x  - (1 * direction) + 1)) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt((
                        position.y) * 9 + (position.x - (1 * direction) + 1))) >= 0)) {
            possibleMoves.add(1);
        }
        // check validity for the move right
        // code 2
        if ((((position.y) * 9 + (position.x  + (1 * direction) + 1)) >= 0) &&
                (((position.y) * 9 + (position.x  + (1 * direction) + 1)) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt((
                        position.y) * 9 + (position.x + (1 * direction) + 1))) >= 0)) {
            possibleMoves.add(2);
        }
        // check validity for the backwards move
        // code 3
        if ((((position.y + (1 * direction)) * 9 + (position.x) + 1) >= 0) &&
                (((position.y + (1 * direction)) * 9 + (position.x) + 1) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt((
                        position.y + (1 * direction)) * 9 + (position.x) + 1)) >= 0)) {
            possibleMoves.add(3);
        }

        // there can be not moves made with this piece
        if (possibleMoves.size() == 0) {
            return null;
        }

        char[] charArray = chessBoard.toCharArray();

        charArray[position.y * 9 + position.x + 1] = '*';

        // Choose at random a move to make on this piece
        // The moves have different weights
        StringBuilder newMove = new StringBuilder();

        newMove.append((char)('a' + position.x));
        newMove.append((position.y + 1));
        newMove.append(chooseTheMove(possibleMoves.get(random.nextInt(possibleMoves.size()))));

        if (XBoard.getInstance().isPlayingWhite()) {
            charArray[position.y * 9 + position.x + 1] = 'r';
        } else {
            charArray[position.y * 9 + position.x + 1] = 'R';
        }

        chessBoard = new String("");
        for(char i:charArray) {
            chessBoard += i;
        }

        Moves.getInstance().setChessBoard(chessBoard);

        move = newMove.toString();
        return move;
    }

    /**
     *
     * @param moveCode This is the code of one of the methods for movement
     * @return
     */
    private String chooseTheMove(Integer moveCode) {
        switch (moveCode) {
            case 0 :
                return this.moveForward();

            case 1 :
                return this.moveLeft();

            case 2 :
                return this.moveRight();

            case 3 :
                return this.moveBack();

        }
        return null;
    }

    @Override
    public Pair getPosition() {
        return this.position;
    }

    @Override
    public void setPosition(Pair position) {
        this.position = position;
    }
}
