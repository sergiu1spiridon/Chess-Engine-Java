

import java.util.ArrayList;
import java.util.Random;

public class Moves {

    private String chessBoard;
    private static Moves instance = null;

    // this 3 change depending on the color we play
    private ArrayList<Piece> AIPieces;
    private String enemyArray;
    private int directionController;

    private Moves() {
        // initialize the pieces the AI has
        this.AIPieces = new ArrayList<>();

        this.enemyArray = "rnbqkbnrp";
        this.directionController = 1;


        // FEN notation for the state of the board
        this.chessBoard = "/rnbqkbnr/pppppppp/********/********/********/********/PPPPPPPP/RNBQKBNR/";

        char[] charArray = this.chessBoard.toCharArray();

        for (int i = 0; i < 73; i++) {
            Piece newPiece = PieceFactory.getPiece(charArray[i], (i % 9 - 1), i / 9);
            if (newPiece != null) {
                this.AIPieces.add(newPiece);
            }
        }
    }

    /**
     * Made singleton so we have the same board around the whole project
     * @return an instance of Moves
     */
    public static Moves getInstance() {
        if (instance == null) {
            instance = new Moves();
        }

        return instance;
    }

    /**
     * Call this method in order to clear the current instance
     * called for new Game command
     * you should call getInstance after
     */
    public static void makeNewBoard() {
        instance = new Moves();
    }

    /**
     *
     * @param move should look like "e4e6"
     *             e4 - initial position
     *             e6 - future position
     */
    public void getPlayerMove(String move) {

        Pair initialPos = new Pair(move.charAt(0) - 'a', Integer.parseInt(String.valueOf(move.charAt(1))) - 1);
        Pair finalPos = new Pair(move.charAt(2) - 'a', Integer.parseInt(String.valueOf(move.charAt(3))) - 1);
        char[] charArray = chessBoard.toCharArray();

        // this should happen on force
        seeIfAIPieceMoved(initialPos, finalPos);

        charArray[(finalPos.y * 8) + finalPos.y + finalPos.x + 1] =
                charArray[(initialPos.y * 8) + initialPos.y + initialPos.x + 1];

        removePiece(finalPos);

        charArray[(initialPos.y * 8) + initialPos.y + initialPos.x + 1] = '*';

        chessBoard = "";
        for(char i:charArray) {
            chessBoard += i;
        }

    }

    /**
     * This function is used to change the position of a piece in AIPieces
     *
     * Used only on force
     *
     * @param initialPair the position of the peice before being moved
     * @param finalPair position where it's supposed to move
     */
    private void seeIfAIPieceMoved(Pair initialPair, Pair finalPair) {
  
        Piece changedPiece = null;

        try {
            changedPiece = AIPieces.stream().filter(piece ->
                    piece.getPosition().equals(initialPair)).findAny().get();

        } catch (java.util.NoSuchElementException e) {
            return;
        }

        changedPiece.setPosition(finalPair);
        if (changedPiece instanceof Pawn) {
            ((Pawn) changedPiece).setFirstMove();
        }
    }

    /**
     * Call this to get a move from the AI
     * ex: sout(makeAMove)
     * @return String in format "e4e6"
     * write this on stdout
     */
    public String makeAMove() {
        StringBuilder move = new StringBuilder("move ");

        if (AIPieces.size() == 0) {
            return "resign";
        }

        Random random = new Random();
        int randomOutput = random.nextInt(AIPieces.size());
        String moveGivenByRandom = AIPieces.get(randomOutput).makeValidMove(chessBoard);

        if (moveGivenByRandom == null) {

            int i = randomOutput + 1;
            while (i != randomOutput) {
                if (i == AIPieces.size()) {
                    i = 0;
                    if (i == randomOutput) {
                        break;
                    }
                }

                moveGivenByRandom = AIPieces.get(i).makeValidMove(chessBoard);

                if (moveGivenByRandom != null) {
                    break;
                }
                i++;
            }
        }

        System.out.println("MOVE: " + moveGivenByRandom);
        if (moveGivenByRandom == null) {
            return "resign";
        }

        System.out.println(chessBoard);

        // add move to the string "move" to make it ready for return
        move.append(moveGivenByRandom);

        return move.toString();
    }

    /**
     * This is called when player makes a move in order to remove the
     * piece that is taken(here we see if there is a piece to be taken too)
     *
     * @param pair this is the position of the piece that is taken
     */
    public void removePiece(Pair pair) {
        AIPieces.removeIf(piece -> {
            return piece.getPosition().equals(pair);
        });
    }

    /**
     *
     * function that should change the needed things for
     * when the color of the pieces the AI plays with changes
     *
     * @param isWhite boolean value is true if the AI plays white
     */
    public void setAIPiecesForColorChange(boolean isWhite) {

        char[] charArray = this.chessBoard.toCharArray();

        this.AIPieces = new ArrayList<>(0);

        if (isWhite) {

            this.enemyArray = "RNBQKBNRP";
            this.directionController = -1;

            for (int i = 0; i < 73; i++) {
                Piece newPiece = PieceFactory.getWhitePieces(charArray[i], i % 9 - 1, i / 9);
                if (newPiece != null) {
                    this.AIPieces.add(newPiece);
                }
            }
        } else {

            this.enemyArray = "rnbqkbnrp";
            this.directionController = 1;

            for (int i = 0; i < 73; i++) {
                Piece newPiece = PieceFactory.getPiece(charArray[i], i % 9 - 1, i / 9);
                if (newPiece != null) {
                    this.AIPieces.add(newPiece);
                }
            }
        }
    }

    public String getChessBoard() {
        return chessBoard;
    }

    public void setChessBoard(String chessBoard) {
        this.chessBoard = chessBoard;
    }

    public ArrayList<Piece> getAIPieces() {
        return AIPieces;
    }

    public void setAIPieces(ArrayList<Piece> AIPieces) {
        this.AIPieces = AIPieces;
    }

    public String getEnemyArray() {
        return enemyArray;
    }

    public void setEnemyArray(String enemyArray) {
        this.enemyArray = enemyArray;
    }

    public int getDirectionController() {
        return directionController;
    }

    public void setDirectionController(int directionController) {
        this.directionController = directionController;
    }


}
