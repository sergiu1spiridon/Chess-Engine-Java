public class XBoard {
    private static XBoard instance;
    private boolean isPause = false;
    private static Moves moves = null;
    private boolean playingWhite = false;

    private XBoard() {}

    public static XBoard getInstance() {
        if (instance == null) {
            instance = new XBoard();
            moves = Moves.getInstance();
        }

        return instance;
    }

    /**
     * Checks if the game is in pause
     * @return
     */
    public boolean isPause() {
        return isPause;
    }

    /**
     * Sets the game status
     * @param pause
     */
    public void setPause(boolean pause) {
        isPause = pause;
    }

    /**
     * Resets the move instance
     */
    public void reset(){
        Moves.makeNewBoard();
        moves = Moves.getInstance();
    }

    /**
     * Sends a move command to the xboard
     */
    public void makeNewMove() {
        if (!this.isPause) {
            System.out.println(moves.makeAMove());
        }
    }

    /**
     * Update the chessboard.
     * @param command e2e4 for example
     */
    public void getPlayerMove(String command) {
        moves.getPlayerMove(command);
    }

    /**
     *
     * Use this function for COLOR.WHITE
     * or COLOR.BLACK
     *
     * If the color changes we set this
     * and here we'll call setAIPiecesForColorChange
     *
     * @param value true is we play with white
     */
    public void setPlayingWhite(boolean value) {
        playingWhite = value;

        Moves.getInstance().setAIPiecesForColorChange(playingWhite);
    }

    public boolean isPlayingWhite() {
        return playingWhite;
    }
}
