

public interface PawnInteface extends Piece{
    // methods characteristic to a pawn

    public String moveForward();
    public String movePrincipalDiagonal();
    public String moveSecondaryDiagonal();
}
