
import java.util.ArrayList;
import java.util.Random;

public class Bishop implements BishopInterface {
    private Pair position;
    private Random random = new Random();

    public Bishop(Pair position) {
        this.position = position;
    }

    @Override
    public String moveFirstDiagonalForward() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while ((((position.y - i * direction) * 9 + (position.x + i * direction) + 1) >= 0) &&
                (((position.y - i * direction) * 9 + (position.x + i * direction) + 1) < 73)) {
            // if we find a blank square we could go further
            // if we find an enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt((position.y - i * direction) * 9 + (position.x + i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt((position.y - i * direction) * 9 + (position.x + i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char) (position.x + numberOfRows * direction + 'a') +
                String.valueOf((position.y + 1 - numberOfRows * direction));
        position.y -= numberOfRows * direction;
        position.x += numberOfRows * direction;

        return move;
    }

    @Override
    public String moveFirstDiagonalBackwards() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while ((((position.y + i * direction) * 9 + (position.x - i * direction) + 1) >= 0) &&
                (((position.y + i * direction) * 9 + (position.x - i * direction) + 1) < 73)) {
            // if we find a blank square we could go further
            // if we find an enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt((position.y + i * direction) * 9 + (position.x - i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt((position.y + i * direction) * 9 + (position.x - i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char) (position.x - numberOfRows * direction + 'a') +
                String.valueOf((position.y + 1 + numberOfRows * direction));
        position.y += numberOfRows * direction;
        position.x -= numberOfRows * direction;

        return move;
    }

    @Override
    public String moveSecondDiagonalForward() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while ((((position.y - i * direction) * 9 + (position.x - i * direction) + 1) >= 0) &&
                (((position.y - i * direction) * 9 + (position.x - i * direction) + 1) < 73)) {
            // if we find a blank square we could go further
            // if we find an enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt((position.y - i * direction) * 9 + (position.x - i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt((position.y - i * direction) * 9 + (position.x - i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char) (position.x - numberOfRows * direction + 'a') +
                String.valueOf((position.y + 1 - numberOfRows * direction));
        position.y -= numberOfRows * direction;
        position.x -= numberOfRows * direction;

        return move;
    }

    @Override
    public String moveSecondDiagonalBackwards() {

        ArrayList<Integer> possibleNumberOfRowsToMove = new ArrayList<>();
        Integer direction = Moves.getInstance().getDirectionController();
        int i = 1;
        String chessBoard = Moves.getInstance().getChessBoard();
        String enemyArray = Moves.getInstance().getEnemyArray();

        while ((((position.y + i * direction) * 9 + (position.x + i * direction) + 1) >= 0) &&
                (((position.y + i * direction) * 9 + (position.x + i * direction) + 1) < 73)) {
            // if we find a blank square we could go further
            // if we find an enemy piece we can take it and stop there
            // if we find one of our pieces we stop before it
            if ("*".indexOf(chessBoard.charAt((position.y + i * direction) * 9 + (position.x + i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                i++;
            } else if (enemyArray.indexOf(chessBoard.charAt((position.y + i * direction) * 9 + (position.x + i * direction) + 1)) >= 0) {
                possibleNumberOfRowsToMove.add(i);
                break;
            } else {
                break;
            }
        }

        Integer numberOfRows = possibleNumberOfRowsToMove.get(random.nextInt(possibleNumberOfRowsToMove.size()));

        String move = (char) (position.x + numberOfRows * direction + 'a') +
                String.valueOf((position.y + 1 + numberOfRows * direction));
        position.y += numberOfRows * direction;
        position.x += numberOfRows * direction;

        return move;
    }

    @Override
    public String makeValidMove(String chessBoard) {
        String move = null;
        ArrayList<Integer> possibleMoves = new ArrayList<>();

        System.out.println(position.x + " " + position.y);

        // change depending on with what pieces the AI plays
        Integer direction = Moves.getInstance().getDirectionController();
        String enemyArray = Moves.getInstance().getEnemyArray() + "*";

        // check validity for the first diagonal forward move
        // code 0
        if ((((position.y - (1 * direction)) * 9 + (position.x + (1 * direction)) + 1) >= 0) &&
                (((position.y - (1 * direction)) * 9 + (position.x + (1 * direction)) + 1) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt((
                        position.y - (1 * direction)) * 9 + (position.x + (1 * direction)) + 1)) >= 0)) {
            possibleMoves.add(0);
        }
        // check validity for the first diagonal backward left
        // code 1
        if ((((position.y + (1 * direction)) * 9 + (position.x - (1 * direction) + 1)) >= 0) &&
                (((position.y + (1 * direction)) * 9 + (position.x - (1 * direction) + 1)) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt(
                        (position.y + (1 * direction)) * 9 + (position.x - (1 * direction) + 1))) >= 0)) {
            possibleMoves.add(1);
        }
        // check validity for the second diagonal forward
        // code 2
        if ((((position.y - (1 * direction)) * 9 + ((position.x - (1 * direction)) + 1)) >= 0) &&
                (((position.y - (1 * direction)) * 9 + (position.x - (1 * direction) + 1)) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt(
                        (position.y - (1 * direction)) * 9 + (position.x - (1 * direction) + 1))) >= 0)) {
            possibleMoves.add(2);
        }
        // check validity for the second diagonal backwards
        // code 3
        if ((((position.y + (1 * direction)) * 9 + (position.x + (1 * direction) + 1)) >= 0) &&
                (((position.y + (1 * direction)) * 9 + (position.x + (1 * direction) + 1)) < 73) &&
                (enemyArray.indexOf(chessBoard.charAt((
                        position.y + (1 * direction)) * 9 + (position.x + (1 * direction) + 1))) >= 0)) {
            possibleMoves.add(3);
        }

        // there can be not moves made with this piece
        if (possibleMoves.size() == 0) {
            return null;
        }

        char[] charArray = chessBoard.toCharArray();

        charArray[position.y * 9 + position.x + 1] = '*';

        // Choose at random a move to make on this piece
        // The moves have different weights
        StringBuilder newMove = new StringBuilder();

        newMove.append((char) ('a' + position.x));
        newMove.append((position.y + 1));
        newMove.append(chooseTheMove(possibleMoves.get(random.nextInt(possibleMoves.size()))));

        if (XBoard.getInstance().isPlayingWhite()) {
            charArray[position.y * 9 + position.x + 1] = 'b';
        } else {
            charArray[position.y * 9 + position.x + 1] = 'B';
        }

        chessBoard = new String("");
        for (char i : charArray) {
            chessBoard += i;
        }

        Moves.getInstance().setChessBoard(chessBoard);

        move = newMove.toString();
        return move;
    }

    private String chooseTheMove(Integer moveCode) {
        switch (moveCode) {
            case 0:
                return this.moveFirstDiagonalForward();

            case 1:
                return this.moveFirstDiagonalBackwards();

            case 2:
                return this.moveSecondDiagonalForward();

            case 3:
                return this.moveSecondDiagonalBackwards();

        }
        return null;
    }

    @Override
    public Pair getPosition() {
        return this.position;
    }


    @Override
    public void setPosition(Pair position) {
        this.position = position;
    }
}
