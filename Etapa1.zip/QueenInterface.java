
public interface QueenInterface extends RookInterface, BishopInterface{
}
