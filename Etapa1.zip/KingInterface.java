
public interface KingInterface extends QueenInterface{
    public Boolean inCheck();
    public Boolean inCheckMate();
    public String getOutOfCheck();
}
